import tkinter as tk
from tkinter import messagebox, filedialog, scrolledtext
import subprocess
import os
import sys
import threading

class WiFi_Emulator:
    def __init__(self, root):
        check_sudo()
        
        log_dir = "/var/log/wifi-emulator"
        os.makedirs(log_dir, exist_ok=True) 

        self.root = root
        self.root.title("WiFi Emulator")
        self.root.geometry("800x800")

        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=5)

        tk.Label(btn_frame, text="Run in sequence, check the help Window:").grid(row=0, column=0, pady=10)
        tk.Button(btn_frame, text="1. Generate Access Point Conf file", command=self.generate_ap_conf).grid(row=1, column=0, padx=5, sticky="w")
        tk.Button(btn_frame, text="Edit ap.conf", command=lambda: self.edit_conf("ap.conf")).grid(row=1, column=1, padx=5, pady=5, sticky="w")
        tk.Button(btn_frame, text="2. Generate Access Client Conf file", command=self.generate_client_conf).grid(row=2, column=0, padx=5, sticky="w")
        tk.Button(btn_frame, text="Edit ac.conf", command=lambda: self.edit_conf("ac.conf")).grid(row=2, column=1, padx=5, pady=5, sticky="w")
        tk.Button(btn_frame, text="3. Create Virtual Interfaces", command=self.interfaces_create).grid(row=3, column=0, padx=5, sticky="w")
        tk.Button(btn_frame, text="Status", command=self.interfaces_status).grid(row=3, column=1, padx=5, pady=5, sticky="w")
        tk.Button(btn_frame, text="4. Start Access Point on wlan0", command=self.hostapd_start).grid(row=4, column=0, padx=5, sticky="w")
        tk.Button(btn_frame, text="Status", command=self.hostapd_status).grid(row=4, column=1, padx=5, pady=5, sticky="w")
        tk.Button(btn_frame, text="5. Start Start Access Client on wlan1", command=self.wpasupplicant_start).grid(row=5, column=0, padx=5, sticky="w")
        tk.Button(btn_frame, text="Status", command=self.wpasupplicant_status).grid(row=5, column=1, padx=5, pady=5, sticky="w")
        tk.Button(btn_frame, text="6. Run Wifite", command=self.run_wifite).grid(row=6, column=0, padx=5, sticky="w")
        tk.Label(btn_frame, text="").grid(row=7, column=0, pady=10)

        button_row = tk.Frame(btn_frame)
        button_row.grid(row=8, column=0)
        tk.Button(button_row, text="Help", command=self.show_help).grid(row=0, column=0, padx=5, sticky="w")
        tk.Button(button_row, text="Reset", command=self.reset_app).grid(row=0, column=1, padx=5, sticky="w")
        tk.Button(button_row, text="Close", command=self.close_app).grid(row=0, column=2, padx=5, sticky="w")

        self.text_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=100, height=30)
        self.text_area.pack(pady=10)

    def show_help(self):
        help_win = tk.Toplevel(self.root)
        help_win.title("Help - WiFi Emulator")
        help_win.geometry("800x700")

        text = scrolledtext.ScrolledText(help_win, wrap=tk.WORD, width=80, height=25)
        text.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        help_text = r"""
    Welcome to WiFi Emulator!

    Run the steps in the following order:
    1. Generate Access Point Conf file
    2. Edit ap.conf if needed
    3. Generate Access Client Conf file
    4. Edit ac.conf if needed
    5. Create Virtual Interfaces
    6. Start Access Point on wlan0
    7. Start Access Client on wlan1
    8. (Optional) Run Wifite for capture/cracking

    Other Buttons:
    - Reset: Remove all virtual interfaces and temp files
    - Close: Exit the application
    - Status: Check the status of network interfaces, wlan0, and wlan1
    - Help: Show this window

    Wifite:
    - Select wlan2 as monitoring interface
    - Select the Access Point TestAP
    - Wifite will try to de-authentiate the Access Client to ceapture the WPA handshake
    - Little wait and you will see the cracked key

    Note:
    - Ensure you run this tool with root (sudo).
    - Use the status buttons to see the outputs.
    - All logs and Wifite cracking results will be saved in /var/run/wpa_supplicant/.

    This application was created for educational and research purposes in 
    cybersecurity teaching labs. The traffic generated between wlan0 and wlan1 is 
    realistic and suitable for hands-on research.

    If you have any questions or suggestions, feel free to email me:
    Kaled Aljebur
        """
        text.insert(tk.END, help_text)
        text.config(state=tk.DISABLED)  

        text.bind("<Control-c>", lambda e: None)

    def log(self, message):
        self.text_area.insert(tk.END, message + '\n')
        self.text_area.see(tk.END)

    def interfaces_create(self):
        cmd = ["modprobe -r mac80211_hwsim && modprobe mac80211_hwsim radios=3"]
        self.run_cmd(cmd, "\nCreating 3 virtual Wi-Fi interfaces; wlan0, wlan1, and wlan2.", use_shell=True)
    
    def interfaces_status(self):
        output = subprocess.check_output(["ip", "a"], stderr=subprocess.STDOUT, text=True)
        self.log(output)

    def generate_ap_conf(self):
        conf = """interface=wlan0
driver=nl80211
ssid=TestAP
channel=6
hw_mode=g
auth_algs=1
wpa=2
wpa_passphrase=sunshine
wpa_key_mgmt=WPA-PSK
rsn_pairwise=CCMP"""
        with open("ap.conf", "w") as f:
            f.write(conf)
        self.log("\nAccess Point ap.conf is generated to be used by wlan0.")

    def generate_client_conf(self):
        conf = """ctrl_interface=/var/run/wpa_supplicant
network={
    ssid=\"TestAP\"
    psk=\"sunshine\"
}
"""
        with open("ac.conf", "w") as f:
            f.write(conf)
        self.log("\nAccess Client ac.conf generated to be used by wlan1.")
    def close_app(self):
        self.root.destroy()

    def reset_app(self):
        cmd = [
            "killall hostapd; "
            "modprobe -r mac80211_hwsim; "
            "killall wpa_supplicant; "
            "rm -f /var/run/wpa_supplicant/* ap.conf ac.conf; "
            "rm -rf /var/log/wifi-emulator/*"
            ]
        self.run_cmd(cmd, "Remove the created interfaces and .conf files", use_shell=True)

    def help_window(self):
        print("Helping")

    def edit_conf(self, filename):
        editor = tk.Toplevel(self.root)
        editor.title(f"Editing {filename}")

        with open(filename, "r") as f:
            content = f.read()

        text = scrolledtext.ScrolledText(editor, wrap=tk.WORD, width=80, height=20)
        text.pack()
        text.insert(tk.END, content)

        def save_changes():
            with open(filename, "w") as f:
                f.write(text.get("1.0", tk.END))
            self.log(f"{filename} saved")
            editor.destroy()

        tk.Button(editor, text="Save", command=save_changes).pack(pady=5)

    def hostapd_start(self):
        log_file = "/var/log/wifi-emulator/AccessPoint.log"
        try:
            with open(log_file, "w") as f:
                process = subprocess.Popen(
                    ["hostapd", "ap.conf"],
                    stdout=f,
                    stderr=subprocess.STDOUT,
                    text=True
                )
            self.log("\nAccess Point started on wlan0 in background. Output saved to /var/log/wifi-emulator/AccessPoint.log")
        except Exception as e:
            self.log(f"Error starting hostapd: {e}")

    def hostapd_status(self):
        try:
            with open("/var/log/wifi-emulator/AccessPoint.log", "r") as f:
                output = f.read()
            self.log("Access Point Output:\n" + output)
        except FileNotFoundError:
            self.log("No Access Point output found yet.")


    def wpasupplicant_start(self):
        def run_wpasupplicant():
            log_file = "/var/log/wifi-emulator/AccessClient.log"
            cmd = "echo '\nWait few seconds to see the connection details below...' && rm -f /var/run/wpa_supplicant/* && wpa_supplicant -i wlan1 -c ac.conf"
            try:
                with open(log_file, "w") as log:
                    process = subprocess.Popen(
                        cmd,
                        shell=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True
                    )
                    self.log("\nStarting Access Client...\nOutput is being logged to /var/log/wifi-emulator/AccessClient.log")
                    for line in process.stdout:
                        self.log(line.strip())
                        log.write(line)
                        log.flush()
                    process.wait()
                    self.log("Access Client finished.")
            except Exception as e:
                self.log(f"Error running Access Client: {e}")

        threading.Thread(target=run_wpasupplicant, daemon=True).start()

    def wpasupplicant_status(self):
        try:
            with open("/var/log/wifi-emulator/AccessClient.log", "r") as f:
                output = f.read()
            self.log("AccessClient Output:\n" + output)
        except FileNotFoundError:
            self.log("No AccessClient output found yet.")

    def run_wifite(self):
        # cmd = ["x-terminal-emulator", "-e", "wifite"]
        cmd = "x-terminal-emulator -e bash -c 'cd /var/log/wifi-emulator; wifite; echo Press any key to exit; read'"
        self.run_cmd(cmd, "Running Wifite in new terminal", use_shell=True)

    def run_cmd(self, cmd, desc="", use_shell=False):
        try:
            subprocess.Popen(cmd, shell=use_shell)
            self.log(f"{desc} started successfully")
        except Exception as e:
            self.log(f"Error running {desc}: {e}")

def check_sudo():
    if os.geteuid() != 0:
        root = tk.Tk()
        root.withdraw() 
        messagebox.showerror("Permission Denied", "❌ Please run this script with sudo/root privileges.")
        root.destroy()
        sys.exit()

if __name__ == "__main__":
    root = tk.Tk()
    app = WiFi_Emulator(root)
    root.mainloop()